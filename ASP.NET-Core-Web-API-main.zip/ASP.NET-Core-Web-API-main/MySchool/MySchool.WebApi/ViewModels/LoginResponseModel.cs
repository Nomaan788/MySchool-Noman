﻿namespace MySchool.WebApi.ViewModels
{
    public class LoginResponseModel
    {
        public string UserName { get; set; }

        public string UserRole { get; set; }
    }
}
